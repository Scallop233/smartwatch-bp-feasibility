# Feasibility and User Experience of a Wrist-Cuff Smartwatch for Ambulatory Blood Pressure Monitoring

Analysis code and summary results for an MSc Health Data Science dissertation
(UCL Institute of Health Informatics, 2026). The project evaluated the
feasibility, usability and acceptability of a validated wrist-cuff blood
pressure smartwatch (Huawei Watch D2) worn during daytime hours across a three-week free-living protocol by six adults with and without diabetes, all existing continuous glucose monitor (CGM) users.

## Repository structure

```
├── code/
│   └── descriptive_statistics.R   # Reproduces Tables A1 and 5 of the dissertation
├── results/
│   └── console_output.txt         # Output of running the script above
└── data/
    └── README.md                  # Data availability statement
```

## Reproducing the results

Requirements: R >= 4.3 (base packages only; no additional packages needed).

```bash
Rscript code/descriptive_statistics.R
```

This prints the item-level Likert descriptives (Table A1 of the
dissertation) and the categorical response frequencies (Table 5). 
`results/console_output.txt` contains the output of this script for
reference.

## Data availability

Raw physiological data are not publicly available. Only the fully anonymised end-of-study questionnaire responses, as reported in the dissertation, are included here.

## Ethics

Ethical approval was granted by the UCL Life and Medical Sciences Research
Ethics Committee (Ethics Application ID: 2680). All participants gave
informed consent. Questionnaire responses were pseudonymised at collection
and fully anonymised after the withdrawal window closed.

## Author and supervision

- Author: Huiqian Wu, MSc Health Data Science, UCL Institute of Health
  Informatics
- Supervisor: Dr Kezhi Li, UCL Institute of Health Informatics
