# Data availability

Raw study data were collected under UCL ethics approval
(Application ID: 2680) and are held in a protected research environment
(UCL Data Safe Haven). They are **not** publicly available.

The only participant data included are the fully
anonymised end-of-study questionnaire responses of the six participants
(five-point Likert items and two categorical items), embedded in the
analysis scripts under `code/` and identical to Table A2 of the
dissertation.
