# Data Availability Statement

The raw data for this study were collected with UCL ethical approval (application number: 2680) and are stored in a secure research environment. These data are not publicly available.

The only participant data included are the questionnaire responses provided by six participants at the end of the study; these data have been fully anonymized and embedded within the analysis scripts in the `code/` directory, matching the content of Table A2 in the thesis exactly.