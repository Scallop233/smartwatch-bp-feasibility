# ---------------------------------------------------------------------------
# Descriptive statistics for the end-of-study usability questionnaire
# Reproduces Table A1 and Table 5 of the dissertation.
# ---------------------------------------------------------------------------


likert <- data.frame(
  dimension = c(
    "Usability", "Usability", "Usability",
    "Comfort & daily integration", "Comfort & daily integration",
    "Comfort & daily integration", "Comfort & daily integration",
    "Technical reliability", "Technical reliability",
    "Perceived accuracy & trust", "Perceived accuracy & trust",
    "Perceived accuracy & trust", "Perceived accuracy & trust",
    "Perceived accuracy & trust", "Perceived accuracy & trust",
    "Acceptability"
  ),
  item = c(
    "Ease of use",
    "Ease of learning",
    "Daytime measurement manageability",
    "Comfort (extended wear)",
    "Comfort (during sleep)",              # overnight wear not required; see 4.5
    "Fit with daily routine",
    "Interference with activities",        # reverse-direction
    "Interrupted/missed measurements",     # reverse-direction
    "Failed chart generation",             # reverse-direction
    "Confidence device was working",
    "Perceived accuracy",
    "Perceived consistency",
    "Ease of posture maintenance",
    "Measurement during physical activity",
    "Usefulness of visualised BP charts",
    "Overall experience"
  ),
  direction = c(
    "higher", "higher", "higher",
    "higher", "higher", "higher", "lower",
    "lower", "lower",
    "higher", "higher", "higher", "higher", "higher", "higher",
    "higher"
  ),
  P1 = c(3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 3, 4, 3, 2, 4, 4),
  P2 = c(3, 3, 3, 4, 4, 3, 3, 3, 3, 4, 3, 3, 3, 3, 3, 4),
  P3 = c(4, 4, 3, 3, 3, 4, 3, 4, 4, 4, 3, 4, 3, 4, 4, 4),
  P4 = c(4, 4, 2, 3, 3, 2, 3, 2, 2, 4, 4, 4, 3, 3, 3, 4),
  P5 = c(5, 3, 3, 5, 5, 4, 1, 3, 1, 5, 5, 5, 4, 2, 5, 5),
  P6 = c(2, 4, 2, 3, 3, 4, 4, 2, 3, 4, 5, 4, 2, 1, 5, 4)
)

resp_cols <- paste0("P", 1:6)
resp      <- as.matrix(likert[, resp_cols])

# --- Table A1: median, mean, min, max per item -----------------------------
table_a1 <- data.frame(
  Dimension = likert$dimension,
  Item      = likert$item,
  Direction = likert$direction,
  Median    = apply(resp, 1, median),
  Mean      = round(apply(resp, 1, mean), 2),
  Min       = apply(resp, 1, min),
  Max       = apply(resp, 1, max)
)

cat("Table A1. Likert-scale responses by item and dimension (1-5 scale)\n")
cat("('lower' marks reverse-direction items, for which lower scores are\n")
cat("favourable; scores were not numerically reversed - see Section 2.4)\n\n")
print(table_a1, row.names = FALSE, right = FALSE)

# --- Table 5: categorical responses ----------------------------------------
categorical <- data.frame(
  participant     = c("2680-001", "2680-002", "2680-003",
                      "2680-004", "2680-005", "2680-006"),
  technical_issue = c("No", "No", "Yes", "No", "No", "Yes"),
  would_use       = c("Yes", "No", "Yes", "Yes", "Yes", "Yes")
)

freq_table <- function(x, label) {
  tab <- table(x)
  data.frame(
    Item     = label,
    Response = names(tab),
    n        = as.integer(tab),
    Percent  = round(100 * as.integer(tab) / length(x))
  )
}

table_5 <- rbind(
  freq_table(categorical$technical_issue, "Technical issues experienced"),
  freq_table(categorical$would_use,       "Would use outside a research study")
)

cat("\nTable 5. Categorical responses\n\n")
print(table_5, row.names = FALSE, right = FALSE)

# --- Result summaries quoted in the text -----------------------------------
cat("\nRange of item medians across the sixteen Likert items:",
    paste(range(table_a1$Median), collapse = " to "), "\n")

act <- resp[likert$item == "Measurement during physical activity", ]
cat("Measurement during physical activity - responses <= 2:",
    sum(act <= 2), "of", length(act), "\n")
